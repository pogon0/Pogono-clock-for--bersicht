# Pogono Clock for Übersicht

A small clock-widget with date in Swedish for Übersicht.

https://tracesof.net/uebersicht/

![Widget Preview](screenshot.png)
